from utils import load_random_word, change_word_ending
from player import Player
from stats import Stats


def game_loop(name_, word_):
    """
    Основной цикл запуска игры
    :param name_:
    :param word_:
    :return stat: возвращает статистику
    """

    count_subwords = word_.get_quantity_subwords
    # Приветственное вступление и знакомство с условиями игры
    # функция change_word_ending("слов", count_subwords) склоняет "слово" в зависимости от кол-ва слов
    print(f'Привет, {name_.get_name}!\n'
          f'Составьте {count_subwords} {change_word_ending("слов", count_subwords)} из слова {word_.get_word.upper()}\n'
          f'Слова должны быть не короче 3 букв\n')

    # Экземпляр класса Stats
    stat = Stats(name_)

    # Запрос ответа от пользователя
    answer_subword = input('Поехали, Ваше первое слово?: ')

    # Основной цикл
    while True:
        # Условие на остановку игры, по окончанию слов либо по желанию игрока
        # И вывод статистики по игре
        if name_.quantity_words == word_.get_quantity_subwords - 1 \
                or answer_subword.lower() in ('stop', 'стоп'):
            return print(f'\n{stat}')

        # Проверка на было ли верное слово введено ранее
        if name_.is_used(answer_subword):
            print('Это слово уже было')
            # Предложение пользователю посмотреть ранее введенные слова
            check = input('Чтоб посмотреть отгаданные слова введите "Да"\n')
            if check.lower() == "да":
                # Выдача пользователю на экран введенных ранее слов
                print(*name_.get_used_word)

        # Проверка на правильность введенного слова
        if word_.is_correct(answer_subword):
            # Добавить в угаданные слова пользователя
            name_.add_word(answer_subword)

        # Фидбэк по результатам проверки
        print(word_.get_feedback(answer_subword))
        # Ввод нового слова пользователем
        answer_subword = input('\nВведите Ваше следующее слово: ')


if __name__ == '__main__':

    word = load_random_word()
    name = Player(input('Введите имя игрока:\n'))

    # Запуск игры
    game_loop(name, word)


    input('Для выхода нажмите Enter')
